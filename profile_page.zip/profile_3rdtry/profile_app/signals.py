from django.db.models.signals import post_save
from django.contrib.auth.models import User
from django.dispatch import receiver
from .models import Profile


# We use the receiver function to get the signal and preform the required task.
# We created a function (create_profile) that will run every time a user is created.
# The function works when a user is saved then a signal will be sent to the receiver
# and the receiver is the create_profile function
# and then when the user is created then a new profile for that user will be created.
@receiver(post_save, sender=User)
def create_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)


# Same logic for the prior function however, it now it will save the profile after it's created.
@receiver(post_save, sender=User)
def save_profile(sender, instance, **kwargs):
    instance.profile.save()
