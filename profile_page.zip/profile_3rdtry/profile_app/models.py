import multiselectfield
from PIL import Image
from django.contrib.auth.models import User
from django.db import models
# we create a class called profile and we inherent from models.Model.
# we then create a one to one relationship with the existing user model.
# we use on_delete method to define what happens when the user is deleted.
# CASCADE is used to order the program to delete the profile if the user is deleted. However, if we delete the profile it won't delete the user.
# we define the name of the images that the user will upload and we also create a diroctory that images will get uploaded to.
from pylint.checkers.typecheck import _


# For first time setup you have to install Pillow by using the command pip install pillow.


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    image = models.ImageField(default='default.jpg', upload_to='profile_pics')


    def __str__(self):
        return f'{self.user.username} Profile'

    # We create this method in order to add the resizing functionality to the image.
    def save(self, *args, **kwargs):
        super(Profile, self).save(*args, **kwargs)
        # This will open the image of the current instance.
        img = Image.open(self.image.path)
        # We specify the size of the image that we want.
        if img.height > 300 or img.width > 300:
            output_size = (300, 300)
            img.thumbnail(output_size)
            img.save(self.image.path)
