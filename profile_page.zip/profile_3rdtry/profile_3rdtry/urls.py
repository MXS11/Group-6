from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path
from profile_app import views as user_views

urlpatterns = [
    path('', admin.site.urls),
    path('profile/', user_views.profile, name='profile'),
]

# We add our MediaUrl and MediaRoot to urls.py as mentioned in django's development page and this will allow our media to work in the browser.
# https://docs.djangoproject.com/en/2.1/howto/static-files/#serving-files-uploaded-by-a-user-during-development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
