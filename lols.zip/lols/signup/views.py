from django.shortcuts import render
# import pyrebase
from django.contrib import auth
from .models import LoggedUser
from django import template
register = template.Library()

# Create your views here.
# Config = {
#   apiKey: "AIzaSyBxXa-e6hMozECvcKsNfwlh29B6D04euYE",
#   authDomain: "iteration-1-demo.firebaseapp.com",
#   databaseURL: "https://iteration-1-demo.firebaseio.com",
#   projectId: "iteration-1-demo",
#   storageBucket: "iteration-1-demo.appspot.com",
#   messagingSenderId: "1039132727742",
#   appId: "1:1039132727742:web:90b6d27db41fdab66a01ef",
#   measurementId: "G-5YP19S69P1"
# };
#
# firebase = pyrebase.initialize_app(config)
# authe = firebase.auth()
# database=firebase.database()


@register.inclusion_tag('./templatetags/logged_in_user_list.html')
def render_logged_in_user_list(request):
    they = get_all_logged_in_users.objects.all().order_by('name')
    return render( request, '/listofusers.html' )
