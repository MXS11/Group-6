from django.urls import path
from . import views

urlpatterns = [
    path('signup/listofusers.html', views.render_logged_in_user_list),
]
