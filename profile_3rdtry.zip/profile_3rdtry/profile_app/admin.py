from django.contrib import admin
from .models import Profile


# We define and customize the things that we will need in the admin page.
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'user_info', 'bio',)

    def user_info(self, obj):
        return obj.bio

    def get_queryset(self, request):
        queryset = super(UserProfileAdmin, self).get_queryset(request)
        queryset = queryset.order_by('user')
        return queryset

    user_info.short_description = 'Info'


# We register the profile model in order to show it in the admin page
admin.site.register(Profile, )
