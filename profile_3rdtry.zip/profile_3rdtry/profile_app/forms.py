from django import forms
from django.contrib.auth.models import User
from .models import Profile


# We create a model form that allows us to work with a database model
class UserUpdateForm(forms.ModelForm):
    email = forms.EmailField()

    class Meta:
        model = User
        fields = ['username', 'email', 'description', 'companies']


# This will allow us to update our image.
class ProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['image']
