from django.contrib.auth.models import User
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils.safestring import mark_safe


class Profile(models.Model):
    STUDENT = 1
    TEACHER = 2

    ROLE_CHOICES = (
        (STUDENT, 'Student'),
        (TEACHER, 'Teacher'),
    )

    photo = models.ImageField(upload_to='photos',blank=True, null=True)
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    birthdate = models.DateField(null=True, blank=True)
    company = models.CharField(max_length=30, blank=True)
    attendance = models.IntegerField(default=0)
    role = models.PositiveSmallIntegerField(choices=ROLE_CHOICES, null=True, blank=True)

    def admin_photo(self):
        return mark_safe('<img src="{}" width="100" />'.format(self.image.url))
    admin_photo.short_description = 'Image'
    admin_photo.allow_tags = True

    def __str__(self):  # __unicode__ for Python 2
        return self.user.username



  # def image_tag(self):
  #       if self.photo:
  #           return mark_safe('<img src="/media/%s" width="50" height="50" />' % (self.photo))
  #       else:
  #           return mark_safe('<img src="/media/document/default.jpg" width="50" height="50" />')
  #
  #   image_tag.short_description = 'Image'

@receiver(post_save, sender=User)
def create_or_update_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)
    instance.profile.save()
