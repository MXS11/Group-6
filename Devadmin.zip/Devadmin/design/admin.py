from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User
from .models import Profile




class Devadmin(admin.ModelAdmin):
    list_display = ( 'user', 'attendance', 'company')
    list_filter = ('company',)
    save_as = True
    save_on_top = True
    change_list_template = 'change_list_graph.html'


admin.site.register(Profile, Devadmin)

# class ProfileInline(admin.StackedInline):
#     model = Profile
#     can_delete = False
#     verbose_name_plural = 'Profile'
#     fk_name = 'user'

# class CustomUserAdmin(admin.ModelAdmin):
#     # inlines = (ProfileInline, )
#     list_display = ('admin_photo', 'username', 'email', 'first_name', 'last_name', 'get_position', 'get_attendance', 'get_company')
#     list_select_related = ('profile', )
#     list_filter = ('company',)
#
#
#     # readonly_fields = ('admin_photo',)
#
#     def get_company(self, instance):
#         return instance.profile.company
#     get_company.short_description = 'Company'
#
#     def get_attendance(self, instance):
#         return instance.profile.attendance
#     get_attendance.short_description = 'Attendance'
#
#     def get_position(self, instance):
#         if (instance.profile.role == 1 ):
#             return "Student"
#         if (instance.profile.role == 2 ):
#             return "teacher"
#
#     get_position.short_description = 'User role'
#
#
#     def get_inline_instances(self, request, obj=None):
#         if not obj:
#             return list()
#         return super(CustomUserAdmin, self).get_inline_instances(request, obj)
#
#
# admin.site.site_header = 'Devpath Administrator'
#
# admin.site.unregister(User)
# admin.site.register(User, CustomUserAdmin)
